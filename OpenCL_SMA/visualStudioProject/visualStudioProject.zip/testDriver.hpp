#pragma once
#include "OpenCL_SMA.hpp"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include<chrono>

#include <CL/cl.h>


